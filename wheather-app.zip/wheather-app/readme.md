#WHEATHER-APP
this is the wheather app mini proj for edureka

here is the codepen link: https://codepen.io/sukhepadda/full/QWBmdBr